'use strict';
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const { Pool } = require('pg');
const { AccessToken, RoomServiceClient } = require('livekit-server-sdk');
const app = express();
app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '1mb' }));
app.use(rateLimit({ windowMs: 60_000, limit: 120, standardHeaders: true, legacyHeaders: false }));
app.use(express.static('public'));
const PORT = process.env.PORT || 3000;
const pool = process.env.DATABASE_URL ? new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.DATABASE_URL.includes('localhost') ? false : { rejectUnauthorized: false } }) : null;
const livekitUrl = process.env.LIVEKIT_URL;
const apiKey = process.env.LIVEKIT_API_KEY;
const apiSecret = process.env.LIVEKIT_API_SECRET;
const roomService = livekitUrl && apiKey && apiSecret ? new RoomServiceClient(livekitUrl, apiKey, apiSecret) : null;
async function initDb(){ if(!pool) return; await pool.query(`CREATE TABLE IF NOT EXISTS rooms (id TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT DEFAULT '', created_by TEXT NOT NULL, created_at TIMESTAMPTZ DEFAULT NOW(), is_active BOOLEAN DEFAULT TRUE)`); }
function requireConfig(res){ if(!pool) {res.status(503).json({error:'DATABASE_URL تنظیم نشده است.'});return false;} if(!roomService){res.status(503).json({error:'تنظیمات LiveKit کامل نیست.'});return false;} return true; }
app.get('/health', async (_req,res)=>res.json({ok:true,service:'ORB BIN'}));
app.get('/api/rooms', async (_req,res)=>{ try { if(!pool) return res.status(503).json({error:'پایگاه داده متصل نیست.'}); const {rows}=await pool.query('SELECT id,name,description,created_by,created_at FROM rooms WHERE is_active=TRUE ORDER BY created_at DESC LIMIT 100'); res.json({rooms:rows}); } catch(e){console.error(e);res.status(500).json({error:'خطا در دریافت اتاق‌ها'});} });
app.get('/api/rooms/:id', async (req,res)=>{ try { if(!pool) return res.status(503).json({error:'پایگاه داده متصل نیست.'}); const {rows}=await pool.query('SELECT id,name,description,created_by FROM rooms WHERE id=$1 AND is_active=TRUE',[req.params.id]); if(!rows.length)return res.status(404).json({error:'اتاق پیدا نشد.'}); res.json({room:rows[0]}); } catch(e){res.status(500).json({error:'خطا در دریافت اتاق'});} });
app.post('/api/rooms', async (req,res)=>{ if(!requireConfig(res))return; try { const name=String(req.body.name||'').trim().slice(0,80); const description=String(req.body.description||'').trim().slice(0,300); const creator=String(req.body.creator||'').trim().slice(0,50); if(name.length<3||creator.length<2) return res.status(400).json({error:'نام اتاق (حداقل ۳ حرف) و نام سازنده را وارد کنید.'}); const id='orb-'+require('crypto').randomBytes(5).toString('hex'); await roomService.createRoom({name:id, emptyTimeout:10, maxParticipants:100}); await pool.query('INSERT INTO rooms(id,name,description,created_by) VALUES($1,$2,$3,$4)',[id,name,description,creator]); res.status(201).json({room:{id,name,description,created_by:creator}}); } catch(e){console.error(e);res.status(500).json({error:'ساخت اتاق انجام نشد. تنظیمات سرویس را بررسی کنید.'});} });
app.post('/api/token', async (req,res)=>{ if(!requireConfig(res))return; try { const room=String(req.body.room||''); const identity=String(req.body.name||'').trim().slice(0,50); if(!identity||identity.length<2) return res.status(400).json({error:'نام نمایشی معتبر وارد کنید.'}); const found=await pool.query('SELECT id FROM rooms WHERE id=$1 AND is_active=TRUE',[room]); if(!found.rowCount) return res.status(404).json({error:'اتاق پیدا نشد یا غیرفعال است.'}); const at=new AccessToken(apiKey,apiSecret,{identity,name:identity,ttl:'2h'}); at.addGrant({roomJoin:true,room,canPublish:true,canSubscribe:true,canPublishData:true}); res.json({token:await at.toJwt(),url:livekitUrl}); } catch(e){console.error(e);res.status(500).json({error:'دریافت مجوز ورود ناموفق بود.'});} });
app.post('/api/rooms/:id/close', async (req,res)=>{ if(!pool)return res.status(503).json({error:'پایگاه داده متصل نیست.'}); try { await pool.query('UPDATE rooms SET is_active=FALSE WHERE id=$1',[req.params.id]); if(roomService) await roomService.deleteRoom(req.params.id).catch(()=>{}); res.json({ok:true}); } catch(e){res.status(500).json({error:'بستن اتاق ناموفق بود.'});} });
app.get('*',(req,res)=>res.sendFile(require('path').join(__dirname,'public','index.html')));
initDb().then(()=>app.listen(PORT,()=>console.log(`ORB BIN listening on ${PORT}`))).catch(e=>{console.error('Database init failed',e);process.exit(1)});
